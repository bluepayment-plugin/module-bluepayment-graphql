<?php

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'BlueMedia_BluePaymentGraphQl', __DIR__);

