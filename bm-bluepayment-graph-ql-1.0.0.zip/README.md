# BlueMedia_BluePaymentGraphQl

Moduł rozszerzający podstawową wersję BlueMedia_BluePayment o API GraphQL.

Instalacja

### Poprzez composera
@ToDo

### Poprzez paczkę .zip
1. Pobrać najnowszą wersję modułu z repozytorium.
2. Wgrać plik .zip do katalogu głównego Magento.
3. Będąc w katalogu głównym Magento, wykonać komendę:
```bash
unzip -o -d app/code/BlueMedia/BluePaymentGraphQl bm-bluepayment-*.zip && rm bm-bluepayment-*.zip
```
4. Przejść do aktywacji modułu.
